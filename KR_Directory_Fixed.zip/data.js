const directoryData = [
  { name: "Santosh Kumar Jha", designation: "CMD", phone: "9004447000" },
  { name: "R M Bhadang", designation: "DIR(F)", phone: "9004447009" }
];